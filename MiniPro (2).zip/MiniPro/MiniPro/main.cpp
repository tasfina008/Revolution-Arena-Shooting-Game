#define FREEGLUT_STATIC
#define GLUT_DISABLE_ATEXIT_HACK
#include <windows.h>
#include <GL/glut.h>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <iostream>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <GL/gl.h>
#define GL_CLAMP_TO_EDGE 0x812F
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
#include<algorithm>
#include <string>


//Background Texture
GLuint enemyTexture;
GLuint enemyTexture2;
GLuint textureID;
GLuint playerTexture;
GLuint PUBLICTexture ;
GLuint enemyTexture_Hasina ;
GLuint bulletTexture2 ;
GLuint PUBSTDTexture;
GLuint bulletTexture;
GLuint obstacleTexture;
GLuint gameOverPRSTDTexture, gameOverPUBLICTexture, PUBLICGameOverTexture;
GLuint gameOverPUBSTDTexture;
GLuint menuBackgroundTexture;
GLuint PUBSTDBackgroundTexture,PUBLICBackgroundTexture, gameBackgroundTexture;
GLuint instructionTexture;

//Objective Counts
int missedEnemies = 0;
int score = 0, highScore = 0;


enum GameState { MENU, PLAYING, GAMEOVER, INSTRUCTION };
GameState gameState = MENU;

enum PlayerType { NONE, PRSTD, PUBSTD, PUBLIC };
PlayerType currentPlayerType = NONE;

struct Vec2
{
    float x, y;
};

class Player
{
public:
    Vec2 pos = {0.0f, -0.9f};
    float speed = 0.05f;
    int health = 3;

    void moveLeft()
    {
        if (pos.x > -0.95f) pos.x -= speed;
    }
    void moveRight()
    {
        if (pos.x <  0.95f) pos.x += speed;
    }
    Vec2 bulletPos()
    {
        return {pos.x, pos.y + 0.08f};
    }
};

class Bullet
{
public:
    Vec2 pos;
    float speed = 0.03f;
    bool destroyed = false;

    Bullet(Vec2 start) : pos(start) {}
    void update()
    {
        pos.y += speed;
        if (pos.y > 1.0f) destroyed = true;
    }
};

class Enemy
{
public:
    Vec2 pos;
    float speed = 0.01f;
    bool destroyed = false;

    Enemy(Vec2 start) : pos(start) {}
    void update()
    {
        pos.y -= speed;
        if (pos.y < -1.0f) destroyed = true;
    }
};


class Enemy2
{
public:
    Vec2 pos;
    float speed = 0.015f;   // faster than Enemy
    bool destroyed = false;

    Enemy2(Vec2 start) : pos(start) {}
    void update()
    {
        pos.y -= speed;
        if (pos.y < -1.0f) destroyed = true;
    }
};


GLuint backgroundTexture;

class Renza
{
public:
    Vec2 pos = {-0.9f, 0.0f};
    float speed = 0.05f;
    int health = 3;

    void moveUp()
    {
        if (pos.y < 0.95f) pos.y += speed;
    }
    void moveDown()
    {
        if (pos.y > -0.95f) pos.y -= speed;
    }
    Vec2 bullet2Pos()
    {
        return {pos.x + 0.05f, pos.y};
    }
};

class Bullet2
{
public:
    Vec2 pos;
    float speed;
    bool destroyed = false;
    bool fromEnemy_hasina;

    Bullet2(Vec2 start, float spd, bool isEnemy_hasina) : pos(start), speed(spd), fromEnemy_hasina(isEnemy_hasina) {}
    void update()
    {
        pos.x += (fromEnemy_hasina ? -speed : speed);
        if (pos.x < -1.0f || pos.x > 1.0f) destroyed = true;
    }
};

class Enemy_hasina
{
public:
    Vec2 pos;
    float speed = 0.005f;
    bool destroyed = false;
    float shootCooldown = 0.0f;

    Enemy_hasina(Vec2 start) : pos(start) {}
    void update()
    {
        pos.x -= speed;
        shootCooldown -= 0.01f;
        if (pos.x < -1.0f) destroyed = true;
    }

    bool canShoot()
    {
        if (shootCooldown <= 0.0f)
        {
            shootCooldown = 1.5f + static_cast<float>(rand() % 100) / 100.0f;
            return true;
        }
        return false;
    }

    Vec2 bullet2Pos()
    {
        return {pos.x - 0.05f, pos.y};
    }
};


class Obstacle
{
public:
    Vec2 pos;
    float speed = 0.005f;
    float width = 0.08f;
    float height = 0.08f;
    bool destroyed = false;

    Obstacle(Vec2 start) : pos(start) {}

    void update()
    {
        pos.y -= speed;
        if (pos.y < -1.0f)
            destroyed = true;
    }
};


Player player;
std::vector<Bullet> bullets;
std::vector<Enemy> enemies;
std::vector<Enemy2> enemies2;
Renza renza;
std::vector<Bullet2> bullets2;
std::vector<Enemy_hasina> enemies_hasina;
std::vector<Obstacle> obstacles;
float enemyTimer = 0.0f;
bool keyStates[256] = { false };


GLuint loadTexture(const char* filename)
{
    int width, height, channels;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load(filename, &width, &height, &channels, STBI_rgb_alpha);
    channels = 4;

    if (!data)
    {
        std::cerr << "[ERROR] Failed to load texture: " << filename << std::endl;
        return 0;
    }

    GLuint texID;
    glGenTextures(1, &texID);
    glBindTexture(GL_TEXTURE_2D, texID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    GLenum format = GL_RGBA;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
    stbi_image_free(data);

    return texID;
}

void drawTexturedRect(Vec2 center, float w, float h)
{
    float x = center.x, y = center.y;
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(x - w, y - h);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(x + w, y - h);
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(x + w, y + h);
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(x - w, y + h);
    glEnd();
}

bool checkCollision(const Bullet& b, const Enemy& e)
{
    return std::abs(b.pos.x - e.pos.x) < 0.05f && std::abs(b.pos.y - e.pos.y) < 0.05f;
}

void updateEnemies_hasina() {
    for (int i = 0; i < enemies2.size(); i++) {
        enemies2[i].pos.y -= enemies2[i].speed;

        // If enemy goes out of screen → missed
        if (enemies2[i].pos.y < -1.0f) {
            missedEnemies++;
            enemies2.erase(enemies2.begin() + i);
            i--;
        }
    }

    // Game over condition
    if (missedEnemies >= 5) {
        gameState = GAMEOVER;
    }
}



void drawTexturedRect2(Vec2 center, float w, float h, float r, float g, float b)
{
    float x = center.x, y = center.y;
    glColor3f(r, g, b);
    glBegin(GL_QUADS);
    glVertex2f(x - w, y - h);
    glVertex2f(x + w, y - h);
    glVertex2f(x + w, y + h);
    glVertex2f(x - w, y + h);
    glEnd();
}

bool checkCollision2(const Vec2& a, const Vec2& b, float radius = 0.05f)
{
    return std::abs(a.x - b.x) < radius && std::abs(a.y - b.y) < radius;
}


void update()
{
    if (gameState != PLAYING) return;
    if (currentPlayerType == PUBSTD || currentPlayerType == PRSTD)
    {
        if (keyStates['a']) player.moveLeft();
        if (keyStates['d']) player.moveRight();
        if (keyStates[' ']) bullets.push_back(Bullet(player.bulletPos()));

        enemyTimer += 0.02f;
        if (enemyTimer > 1.0f)
        {
            float x = (std::rand() % 200) / 100.0f - 1.0f;
            enemies.push_back(Enemy({x, 1.0f}));
            // 30% chance to spawn Enemy2
            if ((rand() % 10) < 3)
            {
                float x2 = (std::rand() % 200) / 100.0f - 1.0f;
                enemies2.push_back(Enemy2({x2, 1.0f}));
            }

            if ((rand() % 2) == 0) // 50% chance
             {
               float ox = (std::rand() % 200) / 100.0f - 1.0f;
               obstacles.push_back(Obstacle({ox, 1.0f}));
             }
            enemyTimer = 0;
        }

        for (auto& b : bullets) b.update();
        for (auto& e : enemies)
        {
            e.update();
            if (!e.destroyed && std::fabs(e.pos.x - player.pos.x) < 0.05f && std::fabs(e.pos.y - player.pos.y) < 0.08f)
            {
                e.destroyed = true;
                player.health--;
                if (player.health <= 0) gameState = GAMEOVER;
            }
            if (e.pos.y < -1.0f)
            {
                e.destroyed = true;
                missedEnemies++;
                if (missedEnemies >= 5) gameState = GAMEOVER;
            }
        }

        for (auto& b : bullets)
        {
            for (auto& e : enemies)
            {
                if (!b.destroyed && !e.destroyed && checkCollision(b, e))
                {
                    b.destroyed = true;
                    e.destroyed = true;
                    score+=10;
                    if (score > highScore) highScore = score;
                }
            }
        }
        for (auto& e2 : enemies2)
        {
            e2.update();

            // collision with player
            if (!e2.destroyed && std::fabs(e2.pos.x - player.pos.x) < 0.07f && std::fabs(e2.pos.y - player.pos.y) < 0.1f)
            {
                e2.destroyed = true;
                player.health--;
                if (player.health <= 0) gameState = GAMEOVER;
            }

            // missed
            if (e2.pos.y < -1.0f)
            {
                e2.destroyed = true;
                missedEnemies++;
                if (missedEnemies >= 5) gameState = GAMEOVER;
            }
        }

// bullet hits Enemy2
        for (auto& b : bullets)
        {
            for (auto& e2 : enemies2)
            {
                if (!b.destroyed && !e2.destroyed && checkCollision(b, *(Enemy*)&e2))
                {
                    b.destroyed = true;
                    e2.destroyed = true;
                    score += 20;
                    if (score > highScore) highScore = score;
                }
            }
        }


        enemies2.erase(std::remove_if(enemies2.begin(), enemies2.end(),
                                      [](Enemy2& e)
        {
            return e.destroyed;
        }), enemies2.end());

        for (auto& ob : obstacles) ob.update();

// Check collision with player
        for (auto& ob : obstacles)
        {
            if (!ob.destroyed && std::abs(ob.pos.x - player.pos.x) < ob.width && std::abs(ob.pos.y - player.pos.y) < ob.height)
            {
                ob.destroyed = true;
                player.health--;
                if (player.health <= 0) gameState = GAMEOVER;
            }
        }

        // Remove destroyed obstacles
       obstacles.erase(std::remove_if(obstacles.begin(), obstacles.end(), [](Obstacle& ob) { return ob.destroyed; }), obstacles.end());


        bullets.erase(std::remove_if(bullets.begin(), bullets.end(), [](Bullet& b)
        {
            return b.destroyed;
        }), bullets.end());
        enemies.erase(std::remove_if(enemies.begin(), enemies.end(), [](Enemy& e)
        {
            return e.destroyed;
        }), enemies.end());
    }

    else
    {
        if (keyStates['w']) renza.moveUp();
        if (keyStates['s']) renza.moveDown();
        if (keyStates[' ']) bullets2.emplace_back(renza.bullet2Pos(), 0.03f, false);

        enemyTimer += 0.02f;
        if (enemyTimer > 1.0f)
        {
            float y = (std::rand() % 200) / 100.0f - 1.0f;
            enemies_hasina.emplace_back(Vec2{1.0f, y});
            enemyTimer = 0;
        }

        for (auto& e : enemies_hasina)
        {
            e.update();
            if (e.pos.x < -1.0f)
            {
                e.destroyed = true;
                missedEnemies++;
                if (missedEnemies >= 5) gameState = GAMEOVER;
            }
            if (e.canShoot())
            {
                bullets2.emplace_back(e.bullet2Pos(), 0.06f, true);// bullet speed
            }
            if (checkCollision2(e.pos, renza.pos))
            {
                renza.health = 0;
            }
        }

        for (auto& b : bullets2)
        {
            b.update();

            if (!b.destroyed && b.fromEnemy_hasina && checkCollision2(b.pos, renza.pos))
            {
                b.destroyed = true;
                renza.health--;
                if (renza.health <= 0) gameState = GAMEOVER;
            }
        }

        for (auto& b : bullets2)
        {
            if (!b.fromEnemy_hasina)
            {
                for (auto& e : enemies_hasina)
                {
                    if (!e.destroyed && checkCollision2(b.pos, e.pos))
                    {
                        b.destroyed = true;
                        e.destroyed = true;
                        score+=10;
                        if (score > highScore) highScore = score;
                    }
                }
            }
        }
        updateEnemies_hasina();

        bullets2.erase(std::remove_if(bullets2.begin(), bullets2.end(), [](Bullet2& b)
        {
            return b.destroyed;
        }), bullets2.end());
        enemies_hasina.erase(std::remove_if(enemies_hasina.begin(), enemies_hasina.end(), [](Enemy_hasina& e)
        {
            return e.destroyed;
        }), enemies_hasina.end());

    }

    glutPostRedisplay();
}

void renderText(float x, float y, const std::string& text, void* font = GLUT_BITMAP_TIMES_ROMAN_24)
{
    glRasterPos2f(x, y);
    for (char c : text) glutBitmapCharacter(font, c);
}

void renderBoldText(float x, float y, const char* text, void* font)
{
    float offset = 0.002f;
    for (int i = 0; i < 5; ++i) {
        float dx = (i % 2) * offset;
        float dy = (i / 2) * offset;
        renderText(x + dx, y + dy, text, font);
    }
}


void drawRect(Vec2 pos, float width, float height, float r, float g, float b)
{
    glColor3f(r, g, b);
    glBegin(GL_QUADS);
    glVertex2f(pos.x - width, pos.y - height);
    glVertex2f(pos.x + width, pos.y - height);
    glVertex2f(pos.x + width, pos.y + height);
    glVertex2f(pos.x - width, pos.y + height);
    glEnd();
}

void drawRect2(Vec2 center, float w, float h, float r, float g, float b)
{
    float x = center.x, y = center.y;
    glColor3f(r, g, b);
    glBegin(GL_QUADS);
    glVertex2f(x - w, y - h);
    glVertex2f(x + w, y - h);
    glVertex2f(x + w, y + h);
    glVertex2f(x - w, y + h);
    glEnd();
}

void drawPlayer(Vec2 pos)
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, (currentPlayerType == PUBSTD) ? PUBSTDTexture : playerTexture);
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    drawTexturedRect(pos, 0.07f, 0.08f);
    glDisable(GL_TEXTURE_2D);
}

void drawEnemy(Vec2 pos)
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, enemyTexture);
    drawTexturedRect(pos, 0.08f, 0.07f);
    glDisable(GL_TEXTURE_2D);
}

void drawEnemy2(Vec2 pos)
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, enemyTexture2); // reuse or load a new texture
    drawTexturedRect(pos, 0.1f, 0.09f);  // slightly bigger
    glDisable(GL_TEXTURE_2D);
}


void renderScoreAndHealth()
{
    glColor3f(0.0f, 1.0f, 0.0f);
    renderText(-0.95f, 0.9f, "Revolution Points: " + std::to_string(score));
    renderText(0.6f, 0.9f, "High Revolution Points: " + std::to_string(highScore));
    float barX = -0.95f, barY = 0.8f;
    float barWidth = 0.05f;
    for (int i = 0; i < player.health; ++i)
        drawRect({barX + i * (barWidth + 0.01f), barY}, barWidth / 2, 0.025f, 0.0f, 1.0f, 0.0f);
}

void render()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_TEXTURE_2D);
    if (gameState == MENU)
        glBindTexture(GL_TEXTURE_2D, menuBackgroundTexture);
    else if (gameState == PLAYING)
    {
        if (currentPlayerType == PUBSTD)
            glBindTexture(GL_TEXTURE_2D, PUBSTDBackgroundTexture);
        else if (currentPlayerType == PRSTD)
            glBindTexture(GL_TEXTURE_2D, gameBackgroundTexture);
        else if (currentPlayerType == PUBLIC)
        {
            glBindTexture(GL_TEXTURE_2D, PUBLICBackgroundTexture);
        }
        else
            glBindTexture(GL_TEXTURE_2D, menuBackgroundTexture);
    }
    drawTexturedRect({0.0f, 0.0f}, 1.0f, 1.0f);
    glDisable(GL_TEXTURE_2D);
    if (gameState == MENU)
    {
        glBindTexture(GL_TEXTURE_2D, menuBackgroundTexture);
    }

    else if (gameState == PLAYING)
    {
        if (currentPlayerType == PUBSTD)
            glBindTexture(GL_TEXTURE_2D, PUBSTDBackgroundTexture);
        else if (currentPlayerType == PRSTD)
            glBindTexture(GL_TEXTURE_2D, gameBackgroundTexture);
        else if (currentPlayerType == PUBLIC)
        {
            glBindTexture(GL_TEXTURE_2D, PUBLICBackgroundTexture);
        }
        else
            glBindTexture(GL_TEXTURE_2D, menuBackgroundTexture);
        renderScoreAndHealth();
    }


    if (gameState == MENU)
    {
        glColor3f(1, 1, 1);
        renderText(-0.1f, 0.3f, "SHOOTING GAME", GLUT_BITMAP_TIMES_ROMAN_24);
        renderText(-0.1f, 0.2f, "Press N to Start Protest as Private Student");
        renderText(-0.1f, 0.1f, "Press G to Start Protest as Public Student");
        renderText(-0.1f, 0.0f, "Press H to Start Protest as Citizen");
        renderText(-0.0f, -0.1f, "Press I for INSTRUCTION");
    }
    else if (gameState == PLAYING)
    {
        if (currentPlayerType == PRSTD )
        {
            drawPlayer(player.pos);
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, bulletTexture);
            for (auto& b : bullets)
            {
                drawTexturedRect(b.pos, 0.01f, 0.015f);
            }
            for (auto& e : enemies)
            {
                drawEnemy(e.pos);
            }
            for (auto& e2 : enemies2)
            {
                drawEnemy2(e2.pos);
            }

            for (auto& ob : obstacles)
            {
                glEnable(GL_TEXTURE_2D);
                glBindTexture(GL_TEXTURE_2D, obstacleTexture);
                drawTexturedRect(ob.pos, ob.width, ob.height);
                glDisable(GL_TEXTURE_2D);
            }

            char buffer[64];
            sprintf(buffer, "Missed: %d / 5", missedEnemies);
            renderText( 0.0f, 0.9f, buffer);
        }
        else if ( currentPlayerType==PUBSTD)

        {
            drawPlayer(player.pos);
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, bulletTexture);
            for (auto& b : bullets)
            {
                drawTexturedRect(b.pos, 0.01f, 0.015f);
            }
            for (auto& e : enemies)
            {
                drawEnemy(e.pos);
            }
            for (auto& e2 : enemies2)
            {
                drawEnemy2(e2.pos);
            }

            for (auto& ob : obstacles)
            {
                glEnable(GL_TEXTURE_2D);
                glBindTexture(GL_TEXTURE_2D, obstacleTexture);
                drawTexturedRect(ob.pos, ob.width, ob.height);
                glDisable(GL_TEXTURE_2D);
            }
            glColor3f(0, 0, 0);
            char buffer[64];
            sprintf(buffer, "Missed: %d / 5", missedEnemies);
            renderText( 0.0f, 0.9f, buffer);
        }
        else
        {
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, PUBLICBackgroundTexture );
            glBindTexture(GL_TEXTURE_2D, PUBLICTexture);
            drawTexturedRect(renza.pos, 0.11f, 0.13f);

            for (auto& b : bullets2)
            {
                if (b.fromEnemy_hasina)
                {
                    glDisable(GL_TEXTURE_2D);
                    drawRect2(b.pos, 0.015f, 0.01f, 1.0f, 1.0f, 0.0f);
                }
                else
                {
                    glEnable(GL_TEXTURE_2D);
                    glBindTexture(GL_TEXTURE_2D, bulletTexture2);
                    drawTexturedRect(b.pos, 0.02f, 0.03f);
                }
            }
            for (auto& e : enemies_hasina)
            {
                glEnable(GL_TEXTURE_2D);
                glBindTexture(GL_TEXTURE_2D, enemyTexture_Hasina);
                drawTexturedRect(e.pos,0.09f, 0.11f);

                glColor3f(1, 1, 1);
            }
            glDisable(GL_TEXTURE_2D);
            char buffer[64];
            sprintf(buffer, "Missed: %d / 5", missedEnemies);
            renderText( 0.0f, 0.9f, buffer);
            renderScoreAndHealth();
        }

    }


    else if (gameState == GAMEOVER)
    {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, PUBLICGameOverTexture);
        drawTexturedRect({0.0f, 0.0f}, 1.0f, 1.0f);
        glDisable(GL_TEXTURE_2D);
        char buffer[64];
        glColor3f(1, 1, 1);
        renderBoldText(-0.1f, -0.8f, "GAME OVER", GLUT_BITMAP_TIMES_ROMAN_24);
        renderText(-0.1f, -0.9f, "Press R to restart", GLUT_BITMAP_TIMES_ROMAN_24);
        glColor3f(0, 0, 0);
        sprintf(buffer, "Missed: %d / 5", missedEnemies);
        renderText(0.0f, 0.9f, buffer);
        renderScoreAndHealth();
    }


    else if (gameState == INSTRUCTION)
    {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, instructionTexture);
        drawTexturedRect({0.0f, 0.0f}, 1.0f, 1.0f);
        glDisable(GL_TEXTURE_2D);

        glColor3f(1, 1, 1);  // Black
        renderText(-0.7f, 0.0f, "INSTRUCTIONS", GLUT_BITMAP_TIMES_ROMAN_24);
        renderText(-0.8f, -0.1f, "1. Press 'N' to play as Private Student.");
        renderText(-0.8f, -0.2f, "2. Press 'G' to play as Public Student.");
        renderText(-0.8f, -0.3f, "2. Press 'H' to play as Citizen.");
        renderText(-0.8f, -0.4f, "3. Move using 'A' and 'D' keys.");
        renderText(-0.8f, -0.5f, "4. Press Space Bar to shoot.");
        renderText(-0.8f, -0.6f, "5. Don't let 3 enemies pass!");
        renderText(-0.8f, -0.7f, "6. Press 'R' to restart after game over.");
        glColor3f(1, 1, 1);
        renderText(-0.8f, -0.9f, "Press 'B' to return to MENU.");
    }

    glutSwapBuffers();
}


void timer(int value)
{
    update();
    glutTimerFunc(16, timer, 0);
}

void keyDown(unsigned char key, int x, int y)
{
    if (gameState == MENU && key == 'g')
    {
        currentPlayerType = PUBSTD;
        gameState = PLAYING;
        player.health = 3;
        score = 0;
        bullets.clear();
        enemies.clear();
        enemyTimer = 0;
        missedEnemies = 0;
    }
    else if (gameState == MENU && key == 'n')
    {
        currentPlayerType = PRSTD;
        gameState = PLAYING;
        player.health = 3;
        score = 0;
        bullets.clear();
        enemies.clear();
        enemyTimer = 0;
        missedEnemies = 0;
    }

    else if (gameState == MENU && key == 'h')
    {
        currentPlayerType = PUBLIC;
        renza = Renza();
        score = 0;
        missedEnemies = 0;
        bullets2.clear();
        enemies_hasina.clear();
        gameState = PLAYING;
    }

    else if (gameState == GAMEOVER && (key == 'r' || key == 'R'))
    {
        gameState = MENU;
        currentPlayerType = NONE;
        bullets.clear();
        enemies.clear();
        enemyTimer = 0;
        missedEnemies = 0;
    }
    else if (gameState == MENU && key == 'i')
    {
        gameState = INSTRUCTION;
    }
    else if (gameState == INSTRUCTION && (key == 'b' || key == 'B'))
    {
        gameState = MENU;
    }
    keyStates[key] = true;
    glutPostRedisplay();
}

void keyUp(unsigned char key, int x, int y)
{
    keyStates[key] = false;
}

int main(int argc, char** argv)
{
    std::srand((unsigned)time(0));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Shooting Game");

    glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);

    PUBSTDBackgroundTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/Picture6.jpg");
    gameBackgroundTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/back1.jpg");
    enemyTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/enemy.png");
    playerTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/man.png");
    PUBSTDTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/Picture4.png");
    bulletTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/knife.png");
    bulletTexture2 = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/gameblade.png");
    enemyTexture_Hasina = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/PUBLICEnemy_hasina.png");
    PUBLICTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/PUBLICpayer.png");
    menuBackgroundTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/back2.jpg");
    PUBLICBackgroundTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/back4.jpg");
    obstacleTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/prison.png");
    enemyTexture2=loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/enemy2.png");
    if (!PUBLICBackgroundTexture)
    {
        std::cerr << "Menu background texture loading failed. Exiting." << std::endl;
        return -1;
    }
        PUBLICGameOverTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/back0.jpg");
    if (!PUBLICGameOverTexture)
    {
        std::cerr << "Menu background texture loading failed. Exiting." << std::endl;
        return -1;
    }
    instructionTexture = loadTexture("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/back.jpg");
    glutDisplayFunc(render);
    glutKeyboardFunc(keyDown);
    glutKeyboardUpFunc(keyUp);
    glutTimerFunc(0, timer, 0);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    PlaySound(TEXT("C:/Users/hi/Downloads/MiniPro/MiniPro/bin/Debug/assets/game.wav"), NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
    glutMainLoop();
    return 0;
}
